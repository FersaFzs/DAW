"use strict"
let ale=Math.floor(Math.random()*6);
//  0-5
ale=Math.floor(Math.random()*50);
//  0-49
ale=Math.floor(Math.random()*50)+1;
//  1-50
ale=Math.floor(Math.random()*51);
//  0-50
ale=Math.floor(Math.random()*51)+1;
//  1-51
