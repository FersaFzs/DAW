DESHABILITAR UN BOTON
boton.disabled="disabled";

-----------------------------
HABILITAR BOTON
boton.disabled="";

