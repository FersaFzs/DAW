"use strict"

let contenido = [
  "El arte de la conversación",
  "Explorando nuevas perspectivas",
  "Innovación y creatividad",
  "Descubriendo nuevos horizontes",
  "Conectando mentes brillantes",
  "Diversidad y unidad",
  "Explorando el cosmos",
  "Crecimiento personal",
  "Transformando el mundo",
  "Descubrimientos fascinantes",
  "Aventuras inesperadas",
  "Desafíos emocionantes",
  "Sueños por realizar",
  "Redefiniendo lo posible",
  "Explorando la naturaleza",
  "Cultivando el conocimiento",
  "Celebrando la vida",
  "Pasión por el aprendizaje",
  "Abrazando la diversidad",
  "Inspirando el cambio",
];


// a) Generar una lista
const lista = null;

// Separador
document.body.appendChild(document.createElement("br"));

// b) Generar una tabla con clase "formato"
const tabla = null;

// Separador
document.body.appendChild(document.createElement("br"));

// c) Generar un datalist
const datalist = null;

// Asociar datalist a un input
const input = null;