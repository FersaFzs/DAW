"use strict";

let tam_y = 150;
let pos_y = 50;
let temporizador_d, temporizador_t;  // para crecimiento y teclado
let activo_teclado = false

// Elementos del DOM


// Evento 'keydown'


// Evento 'click' primer botón


// Evento 'click' segundo botón


// Evento 'click' tercer botón