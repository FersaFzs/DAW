// a) Modificar el texto de los párrafos dentro del div con la clase contenido
const parrafosContenido = null;

// b) Modificar todas las imágenes por la imagen "mario.jpg"
const imagenes = null;

// c) Modificar el input de tipo texto cambiando a 50% su border-radius
const inputTexto = null;

// d) Cambiar los inputs de tipo checkbox a tipo radio
const checkboxes = null;

// e) Seleccionar el div con id "seccion" y sustituir la clase destacado por ornamentado
// Pista: usar classList.remove() y classList.add()
const seccion = null;
