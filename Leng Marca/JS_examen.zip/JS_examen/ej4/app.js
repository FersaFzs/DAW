"use strict";

let x=0, y=0, z=0, r=0;

// Elementos del DOM
const b_sumar = null;
const b_random = null;
const b_binario = null;
const resultado = null;

// Evento sumar


// Evento random


// Evento binario
