let num = parseFloat(prompt("Introduce un número:"));
alert(`Cuadrado: ${num ** 2}\nCubo: ${num ** 3}`);
