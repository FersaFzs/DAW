let alto = parseFloat(prompt("Introduce el alto del rectángulo:"));
let ancho = parseFloat(prompt("Introduce el ancho del rectángulo:"));
let superficie = alto * ancho;
document.write(`<h1>Superficie: ${superficie}</h1>`);
