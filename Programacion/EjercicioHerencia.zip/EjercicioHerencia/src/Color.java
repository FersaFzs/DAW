public enum Color {
    BLANCO, NEGRO, PLATEADO, ROJO, AZUL, GRIS;
}
